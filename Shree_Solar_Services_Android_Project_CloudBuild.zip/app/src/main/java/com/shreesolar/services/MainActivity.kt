package com.shreesolar.services

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val PHONE = "919561801599"
private val Forest = Color(0xFF124734)
private val Gold = Color(0xFFFFC857)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SolarApp() }
    }
}

data class Copy(
    val tagline: String, val solar: String, val schemes: String, val services: String,
    val enquiry: String, val contact: String, val learn: String, val call: String,
    val whatsapp: String, val name: String, val mobile: String, val message: String,
    val send: String, val schemeInfo: String, val solarInfo: String, val serviceInfo: String,
    val disclaimer: String, val home: String, val language: String, val sent: String
)

private val en = Copy(
    "Powering a brighter tomorrow", "Solar Energy", "Government Schemes", "Our Services",
    "Customer Enquiry", "Contact Us", "Explore", "Call Now", "WhatsApp",
    "Your name", "Mobile number", "How can we help?", "Send Enquiry",
    "PM Surya Ghar: Muft Bijli Yojana supports eligible residential households installing rooftop solar. Check current eligibility, subsidy amounts and application steps on the official portal.",
    "Solar panels convert sunlight into electricity. A rooftop system can help reduce grid electricity use. System size depends on your monthly consumption, roof area, shading and local DISCOM rules.",
    "Rooftop solar consultation, system planning, installation coordination, cleaning guidance and maintenance support. Contact us for a site assessment and quotation.",
    "Scheme details and subsidy amounts can change. Always verify eligibility and current rules on the official government portal. Shree Solar Services does not guarantee subsidy approval.",
    "Home", "Language", "Enquiry prepared. Please send it using WhatsApp."
)
private val mr = Copy(
    "उज्ज्वल उद्यासाठी सौरऊर्जा", "सौरऊर्जा", "शासकीय योजना", "आमच्या सेवा",
    "ग्राहक चौकशी", "संपर्क करा", "माहिती पहा", "आता कॉल करा", "व्हॉट्सअॅप",
    "तुमचे नाव", "मोबाईल क्रमांक", "आम्ही कशी मदत करू?", "चौकशी पाठवा",
    "पीएम सूर्य घर: मुफ्त बिजली योजना पात्र निवासी कुटुंबांना छतावरील सौरऊर्जा बसवण्यासाठी सहाय्य करते. पात्रता, अनुदान आणि अर्जाची अद्ययावत माहिती अधिकृत पोर्टलवर तपासा.",
    "सौर पॅनेल सूर्यप्रकाशाचे विजेमध्ये रूपांतर करतात. छतावरील सौर यंत्रणेमुळे वीजबिल कमी होण्यास मदत होऊ शकते. यंत्रणेचा आकार वापर, छताची जागा, सावली आणि स्थानिक नियमांवर अवलंबून असतो.",
    "छतावरील सौरऊर्जा सल्ला, यंत्रणा नियोजन, बसवणी समन्वय, स्वच्छता मार्गदर्शन आणि देखभाल सहाय्य. पाहणी व दरपत्रकासाठी संपर्क करा.",
    "योजना आणि अनुदानाची रक्कम बदलू शकते. पात्रता व नियम अधिकृत सरकारी पोर्टलवर तपासा. अनुदान मंजुरीची हमी Shree Solar Services देत नाही.",
    "मुख्यपृष्ठ", "भाषा", "चौकशी तयार आहे. कृपया WhatsApp द्वारे पाठवा."
)
private val hi = Copy(
    "उज्ज्वल भविष्य के लिए सौर ऊर्जा", "सौर ऊर्जा", "सरकारी योजनाएँ", "हमारी सेवाएँ",
    "ग्राहक पूछताछ", "संपर्क करें", "जानें", "अभी कॉल करें", "व्हाट्सऐप",
    "आपका नाम", "मोबाइल नंबर", "हम आपकी कैसे मदद करें?", "पूछताछ भेजें",
    "पीएम सूर्य घर: मुफ्त बिजली योजना पात्र आवासीय परिवारों को रूफटॉप सोलर लगाने में सहायता देती है। पात्रता, सब्सिडी और आवेदन की ताज़ा जानकारी आधिकारिक पोर्टल पर जाँचें।",
    "सोलर पैनल सूरज की रोशनी को बिजली में बदलते हैं। रूफटॉप सिस्टम से ग्रिड बिजली की खपत कम करने में मदद मिल सकती है। सिस्टम का आकार उपयोग, छत, छाया और स्थानीय नियमों पर निर्भर करता है।",
    "रूफटॉप सोलर सलाह, सिस्टम योजना, इंस्टॉलेशन समन्वय, सफाई मार्गदर्शन और रखरखाव सहायता। साइट निरीक्षण और कोटेशन के लिए संपर्क करें।",
    "योजना और सब्सिडी की राशि बदल सकती है। पात्रता और मौजूदा नियम आधिकारिक सरकारी पोर्टल पर जाँचें। Shree Solar Services सब्सिडी मंज़ूरी की गारंटी नहीं देता।",
    "होम", "भाषा", "पूछताछ तैयार है। कृपया WhatsApp से भेजें।"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SolarApp() {
    var language by remember { mutableStateOf("English") }
    val c = when (language) { "मराठी" -> mr; "हिन्दी" -> hi; else -> en }
    var page by remember { mutableStateOf("home") }
    var customerName by remember { mutableStateOf("") }
    var customerMobile by remember { mutableStateOf("") }
    var customerMessage by remember { mutableStateOf("") }
    var feedback by remember { mutableStateOf("") }
    val context = LocalContext.current

    MaterialTheme(colorScheme = lightColorScheme(primary = Forest, secondary = Gold)) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("☀ SHREE SOLAR SERVICES", fontWeight = FontWeight.Bold, fontSize = 17.sp) },
                    actions = {
                        var expanded by remember { mutableStateOf(false) }
                        Box {
                            TextButton(onClick = { expanded = true }) { Text(c.language) }
                            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                listOf("English", "मराठी", "हिन्दी").forEach { lang ->
                                    DropdownMenuItem(text = { Text(lang) }, onClick = { language = lang; expanded = false })
                                }
                            }
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = page == "home", onClick = { page = "home" }, icon = { Icon(Icons.Default.Home, null) }, label = { Text(c.home) })
                    NavigationBarItem(selected = page == "schemes", onClick = { page = "schemes" }, icon = { Icon(Icons.Default.AccountBalance, null) }, label = { Text(c.schemes) })
                    NavigationBarItem(selected = page == "services", onClick = { page = "services" }, icon = { Icon(Icons.Default.SolarPower, null) }, label = { Text(c.services) })
                    NavigationBarItem(selected = page == "enquiry", onClick = { page = "enquiry" }, icon = { Icon(Icons.Default.EditNote, null) }, label = { Text(c.enquiry) })
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                when (page) {
                    "home" -> {
                        Card(colors = CardDefaults.cardColors(containerColor = Forest), shape = RoundedCornerShape(22.dp)) {
                            Column(Modifier.fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("☀", color = Gold, fontSize = 38.sp)
                                Text("SHREE SOLAR SERVICES", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                                Text(c.tagline, color = Color.White, fontSize = 16.sp)
                                Text("Clean energy • Smart savings", color = Gold, fontWeight = FontWeight.SemiBold)
                                Button(onClick = { page = "enquiry" }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Forest)) { Text(c.enquiry) }
                            }
                        }
                        SectionCard(c.solar, c.solarInfo) { page = "services" }
                        SectionCard(c.schemes, c.schemeInfo) { page = "schemes" }
                        ContactButtons(c, context)
                    }
                    "schemes" -> {
                        Text(c.schemes, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        SectionCard("PM Surya Ghar: Muft Bijli Yojana", c.schemeInfo) {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://pmsuryaghar.gov.in/")))
                        }
                        SectionCard("Official MNRE information", "For central government solar policy, guidelines and official announcements, visit the Ministry of New and Renewable Energy website.") {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://mnre.gov.in/")))
                        }
                        Text(c.disclaimer, color = Color.Gray, fontSize = 12.sp)
                    }
                    "services" -> {
                        Text(c.services, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        SectionCard(c.solar, c.solarInfo) {}
                        SectionCard(c.services, c.serviceInfo) {}
                        SectionCard("Need a quotation?", "Send your details and our team can discuss your rooftop solar requirements.") { page = "enquiry" }
                    }
                    "enquiry" -> {
                        Text(c.enquiry, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        OutlinedTextField(customerName, { customerName = it }, label = { Text(c.name) }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(customerMobile, { customerMobile = it }, label = { Text(c.mobile) }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(customerMessage, { customerMessage = it }, label = { Text(c.message) }, modifier = Modifier.fillMaxWidth(), minLines = 4)
                        Button(onClick = {
                            val body = "Solar enquiry for Shree Solar Services\nName: $customerName\nMobile: $customerMobile\nMessage: $customerMessage"
                            val url = "https://wa.me/$PHONE?text=" + Uri.encode(body)
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                            feedback = c.sent
                        }, modifier = Modifier.fillMaxWidth()) { Text(c.send) }
                        if (feedback.isNotBlank()) Text(feedback, color = Forest)
                    }
                }
                Divider()
                Text(c.contact, fontWeight = FontWeight.Bold)
                Text("+91 95618 01599", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Forest)
                ContactButtons(c, context)
                Text(c.disclaimer, color = Color.Gray, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun SectionCard(title: String, body: String, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Forest)
            Text(body, fontSize = 14.sp)
        }
    }
}

@Composable
fun ContactButtons(c: Copy, context: android.content.Context) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        Button(onClick = { context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:+$PHONE"))) }, modifier = Modifier.weight(1f)) {
            Icon(Icons.Default.Call, null); Spacer(Modifier.width(6.dp)); Text(c.call)
        }
        OutlinedButton(onClick = {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$PHONE?text=" + Uri.encode("Hello Shree Solar Services, I need information about rooftop solar."))))
        }, modifier = Modifier.weight(1f)) {
            Icon(Icons.Default.Chat, null); Spacer(Modifier.width(6.dp)); Text(c.whatsapp)
        }
    }
}
